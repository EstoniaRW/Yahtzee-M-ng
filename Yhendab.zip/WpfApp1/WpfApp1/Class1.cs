﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class Class1
    {
        public int Id { get; set; }
        public int Ühed { get; set; }
        public int Kahed { get; set; }
        public int Kolmed { get; set; }
        public int Neljad { get; set; }
        public int Viied { get; set; }
        public int Kuued { get; set; }
        public int Kolmik { get; set; }
        public int Nelik {  get; set; }
        public int Maja { get; set; }
        public int VäikeRida { get; set; }
        public int SuurRida { get; set; }
        public int Korsten { get; set; }
        public int Yahtzee { get; set; }
    }
}
