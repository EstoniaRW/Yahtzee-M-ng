﻿using System;
using System.Windows;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public bool Kas1Hoia = false; //Kas hoida esimest täringut ehk ei lase täringul veereda
        public bool Kas2Hoia = false; //Kas hoida teist täringut
        public bool Kas3Hoia = false; //Kas hoida kolmandat täringut
        public bool Kas4Hoia = false; //Kas hoida neljandat täringut
        public bool Kas5Hoia = false; //Kas hoida viiendat täringut
        public bool KasOn1 = false; //Kas ühed on olemas ehk kas ühtede väärtus on lisatud tabelisse
        public bool KasOn2 = false; //Kas kahed on olemas
        public bool KasOn3 = false; //Kas kolmed on olemas
        public bool KasOn4 = false; //Kas neljad on olemas
        public bool KasOn5 = false; //Kas viied on olemas
        public bool KasOn6 = false; //Kas kuued on olemas
        public bool KasOnKolmik = false; //Kas kolmik on olemas
        public bool KasOnNelik = false; //Kas nelik on olemas
        public bool KasOnMaja = false; //Kas maja on olemas
        public bool KasOnVäikeRida = false; //Kas väike rida on olemas
        public bool KasOnSuurRida = false; //Kas suur rida on olemas
        public bool KasOnKorsten = false; //Kas korsten on olemas
        public int number1 = 0; //Esimese täringu väärtus
        public int number2 = 0; //Teise täringu väärtus
        public int number3 = 0; //Kolmanda täringu väärtus
        public int number4 = 0; //Neljanda täringu väärtus
        public int number5 = 0; //Viienda täringu väärtus
        public int Veeretusi = 0; //Mitu veeretust on tehtud
        public int[] arvud = new int[5]; //Täringute array ehk järjend
        public string a = "Veeretasid: " + 0.ToString(); //Täringute algseis

        private void Vajuta_nuppu_Click(object sender, RoutedEventArgs e)
        {
            if (Veeretusi < 3)
            {
                Random rand = new Random();          
                //Kui ei paluta täringuid hoida, siis veeretab täringuid ja muudab vastavalt silte täringutel
                if (!Kas1Hoia) { number1 = rand.Next(1, 7); Täring1.Content = "Veeretasid: " + number1.ToString(); }
                if (!Kas2Hoia) { number2 = rand.Next(1, 7); Täring2.Content = "Veeretasid: " + number2.ToString(); }
                if (!Kas3Hoia) { number3 = rand.Next(1, 7); Täring3.Content = "Veeretasid: " + number3.ToString(); }
                if (!Kas4Hoia) { number4 = rand.Next(1, 7); Täring4.Content = "Veeretasid: " + number4.ToString(); }
                if (!Kas5Hoia) { number5 = rand.Next(1, 7); Täring5.Content = "Veeretasid: " + number5.ToString(); }
                //Annab väärtused arvude järjendile ehk arrayle
                arvud[0] = number1; arvud[1] = number2; arvud[2] = number3; arvud[3] = number4; arvud[4] = number5;
                Veeretusi++;
                //Silt näitab mitu korda on veeretatud koos lisaklausliga, et kui on kolm korda, siis lisab, et peab väärtuse tabelisse valima
                Veeretatud.Content = (Veeretusi == 3) ? "Oled veeretanud " + Veeretusi.ToString() + " korda, vali väärtus tabelisse." : "Oled veeretanud " + Veeretusi.ToString() + " korda.";
            }
        }
        
        private void Hoia1_Click(object sender, RoutedEventArgs e)
        {
            Kas1Hoia = !Kas1Hoia;
            //Muudab nupu sisu vastavalt olekule, kas "hoia" või "hoian"
            Hoia1.Content = (Kas1Hoia) ? "Hoian" : "Hoia";
        }

        private void Hoia2_Click(object sender, RoutedEventArgs e)
        {
            Kas2Hoia = !Kas2Hoia;
            Hoia2.Content = (Kas2Hoia) ? "Hoian" : "Hoia";
        }

        private void Hoia3_Click(object sender, RoutedEventArgs e)
        {
            Kas3Hoia = !Kas3Hoia;
            Hoia3.Content = (Kas3Hoia) ? "Hoian" : "Hoia";
        }

        private void Hoia4_Click(object sender, RoutedEventArgs e)
        {
            Kas4Hoia = !Kas4Hoia;
            Hoia4.Content = (Kas4Hoia) ? "Hoian" : "Hoia";
        }

        private void Hoia5_Click(object sender, RoutedEventArgs e)
        {
            Kas5Hoia = !Kas5Hoia;
            Hoia5.Content = (Kas5Hoia) ? "Hoian" : "Hoia";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn1)
            {
                ÜksLabel.Content = MituNumbrit(1, arvud);
                ÜksNupp.Content = "Olemas";
                KasOn1 = true;
                Refresh();
            }
        }

        private void KaksNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn2)
            {
                KaksLabel.Content = MituNumbrit(2, arvud);
                KaksNupp.Content = "Olemas";
                KasOn2 = true;
                Refresh();
            }
        }
        private void KolmNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn3)
            {
                KolmLabel.Content = MituNumbrit(3, arvud);
                KolmNupp.Content = "Olemas";
                KasOn3 = true;
                Refresh();
            }
        }
        private void NeliNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn4)
            {
                NeliLabel.Content = MituNumbrit(4, arvud);
                NeliNupp.Content = "Olemas";
                KasOn4 = true;
                Refresh();
            }
        }

        private void ViisNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn5)
            {
                ViisLabel.Content = MituNumbrit(5, arvud);
                ViisNupp.Content = "Olemas";
                KasOn5 = true;
                Refresh();
            }
        }

        private void KuusNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn6)
            {
                KuusLabel.Content = MituNumbrit(6, arvud);
                KuusNupp.Content = "Olemas";
                KasOn6 = true;
                Refresh();
            }
        }
        public static int MituNumbrit(int otsitav, int[] arr)
        {
            int esineb = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == otsitav)
                {
                    esineb++;
                }
            }
            return esineb*otsitav;
        }
        public void Refresh()
        {
            Veeretusi = 0;
            Veeretatud.Content = (Veeretusi == 3) ? "Oled veeretanud " + Veeretusi.ToString() + " korda, vali väärtus tabelisse." : "Oled veeretanud " + Veeretusi.ToString() + " korda.";
            number1 = 0; number2 = 0; number3 = 0; number4 = 0; number5 = 0;
            Täring1.Content = a; Täring2.Content = a; Täring3.Content = a; Täring4.Content = a; Täring5.Content = a;
            Kas1Hoia = false; Kas2Hoia = false; Kas3Hoia = false; Kas4Hoia = false; Kas5Hoia = false;
            Hoia1.Content = "Hoia"; Hoia2.Content = "Hoia"; Hoia3.Content = "Hoia"; Hoia4.Content = "Hoia"; Hoia5.Content = "Hoia";
        }

        
    }
}
