﻿using System;
using System.Windows;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //Kasutatud on https://cardgames.io/yahtzee/#rules reegleid, ilma mitme yahtzee reeglita
        public bool Kas1Hoia = false; //Kas hoida esimest täringut ehk ei lase täringul veereda
        public bool Kas2Hoia = false; //Kas hoida teist täringut
        public bool Kas3Hoia = false; //Kas hoida kolmandat täringut
        public bool Kas4Hoia = false; //Kas hoida neljandat täringut
        public bool Kas5Hoia = false; //Kas hoida viiendat täringut
        public bool KasOn1 = false; //Kas ühed on olemas ehk kas ühtede väärtus on lisatud tabelisse
        public bool KasOn2 = false; //Kas kahed on olemas                   2
        public bool KasOn3 = false; //Kas kolmed on olemas                  3
        public bool KasOn4 = false; //Kas neljad on olemas                  4
        public bool KasOn5 = false; //Kas viied on olemas                   5
        public bool KasOn6 = false; //Kas kuued on olemas                   6
        public bool KasOnKolmik = false; //Kas kolmik on olemas             7
        public bool KasOnNelik = false; //Kas nelik on olemas               8
        public bool KasOnMaja = false; //Kas maja on olemas                 9
        public bool KasOnVäikeRida = false; //Kas väike rida on olemas      10
        public bool KasOnSuurRida = false; //Kas suur rida on olemas        11
        public bool KasOnKorsten = false; //Kas korsten on olemas           12
        public bool KasOnYahtzee = false; //Kas Yahtzee on olemas           13
        public int number1 = 0; //Esimese täringu väärtus                   Sõnastike võtmed, sest arrayle ei saa elemente lisada
        public int number2 = 0; //Teise täringu väärtus
        public int number3 = 0; //Kolmanda täringu väärtus
        public int number4 = 0; //Neljanda täringu väärtus
        public int number5 = 0; //Viienda täringu väärtus
        public int Veeretusi = 0; //Mitu veeretust on tehtud
        public int[] arvud = new int[5]; //Täringute array ehk järjend
        public int[] järjestarvud = new int[5]; //Täringute array ehk järjend madalamast suuremani
        Dictionary<int, int> sõnastik = new Dictionary<int, int>(); //Sõnastik väärtuste jaoks tabelis
        public string a = "Veeretasid: " + 0.ToString(); //Täringute algseis
        public bool Läbi = false; //Kas mäng on läbi

        private void Vajuta_nuppu_Click(object sender, RoutedEventArgs e)
        { 
            if (Läbi) { UusMäng(); }
            if (Veeretusi < 3)
            {
                Random rand = new Random();
                //Kui ei paluta täringuid hoida, siis veeretab täringuid ja muudab vastavalt silte täringutel
                if (!Kas1Hoia) { number1 = rand.Next(1, 7); Täring1.Content = "Veeretasid: " + number1.ToString(); }
                if (!Kas2Hoia) { number2 = rand.Next(1, 7); Täring2.Content = "Veeretasid: " + number2.ToString(); }
                if (!Kas3Hoia) { number3 = rand.Next(1, 7); Täring3.Content = "Veeretasid: " + number3.ToString(); }
                if (!Kas4Hoia) { number4 = rand.Next(1, 7); Täring4.Content = "Veeretasid: " + number4.ToString(); }
                if (!Kas5Hoia) { number5 = rand.Next(1, 7); Täring5.Content = "Veeretasid: " + number5.ToString(); }
                //Annab väärtused arvude järjendile ehk arrayle
                arvud[0] = number1; arvud[1] = number2; arvud[2] = number3; arvud[3] = number4; arvud[4] = number5;
                Veeretusi++;
                //Silt näitab mitu korda on veeretatud koos lisaklausliga, et kui on kolm korda, siis lisab, et peab väärtuse tabelisse valima
                Veeretatud.Content = (Veeretusi == 3) ? "Oled veeretanud " + Veeretusi.ToString() + " korda, vali väärtus tabelisse." : "Oled veeretanud " + Veeretusi.ToString() + " korda.";
                järjestarvud = (from element in arvud orderby element ascending select element).ToArray();
            }
        }

        private void Hoia1_Click(object sender, RoutedEventArgs e)
        {
            Kas1Hoia = !Kas1Hoia;
            //Muudab nupu sisu vastavalt olekule, kas "hoia" või "hoian"
            Hoia1.Content = (Kas1Hoia) ? "Hoian" : "Hoia";
        }

        private void Hoia2_Click(object sender, RoutedEventArgs e)
        {
            Kas2Hoia = !Kas2Hoia;
            Hoia2.Content = (Kas2Hoia) ? "Hoian" : "Hoia";
        }

        private void Hoia3_Click(object sender, RoutedEventArgs e)
        {
            Kas3Hoia = !Kas3Hoia;
            Hoia3.Content = (Kas3Hoia) ? "Hoian" : "Hoia";
        }

        private void Hoia4_Click(object sender, RoutedEventArgs e)
        {
            Kas4Hoia = !Kas4Hoia;
            Hoia4.Content = (Kas4Hoia) ? "Hoian" : "Hoia";
        }

        private void Hoia5_Click(object sender, RoutedEventArgs e)
        {
            Kas5Hoia = !Kas5Hoia;
            Hoia5.Content = (Kas5Hoia) ? "Hoian" : "Hoia";
        }

        private void ÜksNupp_Click(object sender, RoutedEventArgs e)
        {
            //Kui ühtede tulp ei ole täidetud, siis lisab väärtused meetodiga,
            //värskendab veeretused, muudab siltide väärtuseid ja lisab ühtede
            //väärtuse sõnastikku ja nii iga lahtriga
            if (!KasOn1)
            {
                ÜksLabel.Content = MituNumbrit(1, arvud);
                ÜksNupp.Content = "Ühed olemas";
                KasOn1 = true;
                sõnastik.Add(1, MituNumbrit(1, arvud));
                Refresh();
            }
        }

        private void KaksNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn2)
            {
                KaksLabel.Content = MituNumbrit(2, arvud);
                KaksNupp.Content = "Kahed olemas";
                KasOn2 = true;
                sõnastik.Add(2, MituNumbrit(2, arvud));
                Refresh();
            }
        }
        private void KolmNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn3)
            {
                KolmLabel.Content = MituNumbrit(3, arvud);
                KolmNupp.Content = "Kolmed olemas";
                KasOn3 = true;
                sõnastik.Add(3, MituNumbrit(3, arvud));
                Refresh();
            }
        }
        private void NeliNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn4)
            {
                NeliLabel.Content = MituNumbrit(4, arvud);
                NeliNupp.Content = "Neljad olemas";
                KasOn4 = true;
                sõnastik.Add(4, MituNumbrit(4, arvud));
                Refresh();
            }
        }

        private void ViisNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn5)
            {
                ViisLabel.Content = MituNumbrit(5, arvud);
                ViisNupp.Content = "Viied olemas";
                KasOn5 = true;
                sõnastik.Add(5, MituNumbrit(5, arvud));
                Refresh();
            }
        }

        private void KuusNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn6)
            {
                KuusLabel.Content = MituNumbrit(6, arvud);
                KuusNupp.Content = "Kuued olemas";
                KasOn6 = true;
                sõnastik.Add(6, MituNumbrit(6, arvud));
                Refresh();
            }
        }
        private void KolmikNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnKolmik)
            {
                KolmikLabel.Content = Kolmik(järjestarvud);
                KolmikNupp.Content = "Kolmik olemas";
                KasOnKolmik = true;
                sõnastik.Add(7, Kolmik(järjestarvud));
                Refresh();
            }

        }

        private void NelikNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnNelik)
            {
                NelikLabel.Content = Nelik(järjestarvud);
                NelikNupp.Content = "Nelik olemas";
                KasOnNelik = true;
                sõnastik.Add(8, Nelik(järjestarvud));
                Refresh();
            }
        }

        private void MajaNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnMaja)
            {
                MajaLabel.Content = Maja(järjestarvud);
                MajaNupp.Content = "Maja olemas";
                KasOnMaja = true;
                sõnastik.Add(9, Maja(järjestarvud));
                Refresh();
            }
        }

        private void VäikeNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnVäikeRida)
            {
                VäikeLabel.Content = Väike(järjestarvud);
                VäikeNupp.Content = "Väike rida olemas";
                KasOnVäikeRida = true;
                sõnastik.Add(10, Väike(järjestarvud));
                Refresh();
            }
        }

        private void SuurNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnSuurRida)
            {
                SuurLabel.Content = Suur(järjestarvud);
                SuurNupp.Content = "Suur rida olemas";
                KasOnSuurRida = true;
                sõnastik.Add(11, Suur(järjestarvud));
                Refresh();
            }
        }

        private void KorstenNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnKorsten)
            {
                KorstenLabel.Content = Summa(järjestarvud);
                KorstenNupp.Content = "Korsten olemas";
                KasOnKorsten = true;
                sõnastik.Add(12, Summa(järjestarvud));
                Refresh();
            }
        }

        private void YahtzeeNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnYahtzee)
            {
                YahtzeeLabel.Content = Yahtzee(järjestarvud);
                YahtzeeNupp.Content = "Yahtzee olemas";
                KasOnYahtzee = true;
                sõnastik.Add(13, Yahtzee(järjestarvud));
                Refresh();
            }
            
        }
        public static int MituNumbrit(int otsitav, int[] arr)
        {
            //Leiab mitu korda number esineb ning tagastab esinemisarvu korrutise
            //antud numbriga, et saada väärtuse
            int esineb = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == otsitav)
                {
                    esineb++;
                }
            }
            return esineb * otsitav;
        }
        public void Refresh()
        {
            //Värskendab veeretused nulli ja muudab täringud nulliks ning hoia vääraks
            Veeretusi = 0;
            Veeretatud.Content = "Oled veeretanud " + Veeretusi.ToString() + " korda.";
            number1 = 0; number2 = 0; number3 = 0; number4 = 0; number5 = 0;
            Täring1.Content = a; Täring2.Content = a; Täring3.Content = a; Täring4.Content = a; Täring5.Content = a;
            Kas1Hoia = false; Kas2Hoia = false; Kas3Hoia = false; Kas4Hoia = false; Kas5Hoia = false;
            Hoia1.Content = "Hoia"; Hoia2.Content = "Hoia"; Hoia3.Content = "Hoia"; Hoia4.Content = "Hoia"; Hoia5.Content = "Hoia";
            arvud[0] = 0; arvud[1] = 0; arvud[2] = 0; arvud[3] = 0; arvud[4] = 0;
            järjestarvud[0] = 0; järjestarvud[1] = 0; järjestarvud[2] = 0; järjestarvud[3] = 0; järjestarvud[4] =  0;
            KasMängOnLäbi();
        }
        public static int Kolmik(int[] arr)
        {
            //Kontrollib kolmiku olemasolu ja tagastab väärtuse
            //edasised kontrollivad teisi lahtreid
            int Väärtus = 0;
            if ((arr[0] == arr[2]) || ( arr[1] == arr[3]) || (arr[2] == arr[4]))
            {
                Väärtus = Summa(arr);
            }
            return Väärtus;
        }
        public static int Nelik(int[] arr)
        {
            int Väärtus = 0;
            if ((arr[0] == arr[3]) || (arr[1] == arr[4]))
            {
                Väärtus = Summa(arr);
            }
            return Väärtus;
        }
        public static int Maja(int[] arr)
        {
            int Väärtus = 0;
            if ((arr[0] == arr[2] & arr[3] == arr[4]& arr[0] != arr[4]) || (arr[0] == arr[1] & arr[2] == arr[4] & arr[0] != arr[4]))
            {
                Väärtus = 25;
            }
            return Väärtus;
        }
        public static int Väike(int[] arr)
        {
            int Väärtus = 0;
            if ((arr[0] + 1 == arr[1] & arr[0] + 2 == arr[2] & arr[0] + 3 == arr[3]) || (arr[1] + 1 == arr[2] & arr[1] + 2 == arr[3] & arr[1] + 3 == arr[4]))
            {
                Väärtus = 30;
            }
            return Väärtus;
        }
        public static int Suur(int[] arr)
        {
            int Väärtus = 0;
            if (arr[0] + 1 == arr[1] & arr[0] + 2 == arr[2] & arr[0] + 3 == arr[3] & arr[0] + 4 == arr[4])
            {
                Väärtus = 40;
            }
            return Väärtus;
        }
        public static int Yahtzee(int[] arr)
        {
            int Väärtus = 0;
            if (arr[0] == arr[4] & arr[0]!=0)
            {
                Väärtus =50;
            }
            return Väärtus;
        }
        public static int Summa(int[] arr)
        {
            return arr[0] + arr[1] + arr[2] + arr[3] + arr[4];
        }
        public void KasMängOnLäbi()
        {
            //Kontrollib, kas mäng on läbi, kui on, siis lisab lõpetamissildi
            if (KasOn1&KasOn2&KasOn3&KasOn4&KasOn5&KasOn6&KasOnKolmik&KasOnNelik&KasOnMaja&KasOnSuurRida&KasOnVäikeRida&KasOnKorsten&KasOnYahtzee)
            {
                int puhver = 0;
                foreach (var ele in sõnastik)
                {
                    puhver += ele.Value;
                }
                MängLõpp.Content = "Mäng lõppes \nsinu summaks on:\n" + puhver.ToString() + " punkti";
                Vajuta_nuppu.Content = "Alusta uut mängu";
                Läbi = true;

            }
        }
        public void UusMäng()
        {
            //Alustab uut mängu, värskendab kõik algseisu
            KasOn1 = false;KasOn2 = false;KasOn3 = false;KasOn4 = false;KasOn5 = false;KasOn6 = false;
            KasOnKolmik = false;KasOnNelik = false;KasOnMaja = false;KasOnSuurRida = false;KasOnVäikeRida = false;KasOnKorsten = false; KasOnYahtzee = false;
            ÜksLabel.Content = "";KaksLabel.Content = "";KolmLabel.Content = ""; NeliLabel.Content = ""; ViisLabel.Content = ""; KuusLabel.Content = "";
            KolmikLabel.Content = ""; NelikLabel.Content = ""; MajaLabel.Content = ""; SuurLabel.Content = ""; VäikeLabel.Content = ""; KorstenLabel.Content = ""; YahtzeeLabel.Content = "";
            Vajuta_nuppu.Content = "Veereta täringuid";
            MängLõpp.Content = "";
            Veeretusi = 0;
            Refresh();
            sõnastik.Clear();
        }


    }
}
