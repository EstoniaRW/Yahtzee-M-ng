﻿using System.Data.SqlClient;
using System.Windows;


namespace WpfFramesExample
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public string connectionString = //Ühendumissõne
               "Server=tcp:vhk-12r.database.windows.net,1433;" +
               "Initial Catalog=Nimetu;" +
               "User ID=Nimetu;" +
               "Password=oG5fBnyP;" +
               "Encrypt=True;" +
               "TrustServerCertificate=False;" +
               "Connection Timeout=30;";


        private void BtnPage1_Click(object sender, RoutedEventArgs e)
        {
            KasUus();
            MainFrame.Navigate(new Page1());
            Uus.Visibility = Visibility.Collapsed;
            Jätka.Visibility = Visibility.Collapsed;
            High.Visibility = Visibility.Collapsed;
            Tervitus.Visibility = Visibility.Collapsed;
        }

        private void BtnPage2_Click(object sender, RoutedEventArgs e)
        {
            KasJätkab();
            MainFrame.Navigate(new Page1());
            Uus.Visibility = Visibility.Collapsed;
            Jätka.Visibility = Visibility.Collapsed;
            High.Visibility = Visibility.Collapsed;
            Tervitus.Visibility = Visibility.Collapsed;
        }
        private void High_Click(object sender, RoutedEventArgs e)
        {
            ResetHigh();
        }
        private void ResetHigh()
        {
            string queryString = "Update Highscore set High = 0";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command2 = new SqlCommand(queryString, connection);
                connection.Open();
                command2.ExecuteNonQuery();
                connection.Close();
            }
        }
        private void KasJätkab()
        {
            string queryString = "Update Jätka set Kas1=1"; //Kõver viis teha, aga saab sellega tehtud
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command2 = new SqlCommand(queryString, connection);
                connection.Open();
                command2.ExecuteNonQuery();
                connection.Close();
            }
        }
        private void KasUus()
        {
            string queryString = "Update Jätka set Kas2=1"; //Kõver viis teha, aga saab sellega tehtud
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command2 = new SqlCommand(queryString, connection);
                connection.Open();
                command2.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}
