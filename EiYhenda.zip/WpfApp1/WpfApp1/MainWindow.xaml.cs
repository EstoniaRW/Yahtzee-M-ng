﻿using System;
using System.Configuration;
using System.Data;
using System.Windows;
using MySql.Data.MySqlClient;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            string connectionString = "SERVER=vhk-12r.database.windows.net;DATABASE=Nimetu;UID=Nimetu;PASSWORD=oG5fBnyP";
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlCommand cmd = new MySqlCommand("select * from ", connection);
            connection.Open();
            DataTable dt = new DataTable();
            dt.Load(cmd.ExecuteReader());
            connection.Close();

            dtGrid.DataContext = dt;
        } 



        public bool Kas1Hoia = false;
        public bool Kas2Hoia = false;
        public bool Kas3Hoia = false;
        public bool Kas4Hoia = false;
        public bool Kas5Hoia = false;

        //public int Veeretatud = 0;
        private void Vajuta_nuppu_Click(object sender, RoutedEventArgs e)
        {
            
            Random rand = new Random();

            int number1 = rand.Next(1, 7);
            int number2 = rand.Next(1, 7);
            int number3 = rand.Next(1, 7);
            int number4 = rand.Next(1, 7);
            int number5 = rand.Next(1, 7);

            // If "Hoia" is not pressed, roll the dice
            if (!Kas1Hoia) 
            {Täring1.Content = "You rolled: " + number1.ToString();}
            if (!Kas2Hoia) 
            {Täring2.Content = "You rolled: " + number2.ToString();}
            if (!Kas3Hoia) 
            {Täring3.Content = "You rolled: " + number3.ToString();}
            if (!Kas4Hoia) 
            {Täring4.Content = "You rolled: " + number4.ToString();}
            if (!Kas5Hoia) 
            {Täring5.Content = "You rolled: " + number5.ToString();}
            //Veeretatud += 1;
            //Vajuta_nuppu.Content = "Vajuta nuppu " + Veeretatud.ToString();
        }

        private void Hoia1_Click(object sender, RoutedEventArgs e)
        {
            Kas1Hoia = !Kas1Hoia;

            // Change the button content to "Hoian" if the dice is held
            if (Kas1Hoia)
            {
                Hoia1.Content = "Hoian";
            }
            else
            {
                Hoia1.Content = "Hoia";
            }
        }

        private void Hoia2_Click(object sender, RoutedEventArgs e)
        {
            Kas2Hoia = !Kas2Hoia;
            if (Kas2Hoia)
            {
                Hoia2.Content = "Hoian";
            }
            else
            {
                Hoia2.Content = "Hoia";
            }
        }

        private void Hoia3_Click(object sender, RoutedEventArgs e)
        {
            Kas3Hoia = !Kas3Hoia;
            if (Kas3Hoia)
            {
                Hoia3.Content = "Hoian";
            }
            else
            {
                Hoia3.Content = "Hoia";
            }
        }

        private void Hoia4_Click(object sender, RoutedEventArgs e)
        {
            Kas4Hoia = !Kas4Hoia;
            if (Kas4Hoia)
            {
                Hoia4.Content = "Hoian";
            }
            else
            {
                Hoia4.Content = "Hoia";
            }
        }

        private void Hoia5_Click(object sender, RoutedEventArgs e)
        {
            Kas5Hoia = !Kas5Hoia;
            if (Kas5Hoia)
            {
                Hoia5.Content = "Hoian";
            }
            else
            {
                Hoia5.Content = "Hoia";
            }
        } 
    }
}
