﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfFramesExample
{
    /// <summary>
    /// Interaction logic for Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
            if (KasJätkab1(connectionString)) //Kas vajutati jätka mängu nuppu, tehtud kõveral viisil
            {
                Jätka_Click();
                EiJätka1();
            }
            if (KasJätkab2(connectionString)) //Kas vajutati uus mäng nuppu
            {
                AlgTabel(connectionString);
                EiJätka2();
            }
        }
        
        
        public bool Kas1Hoia = false; //Kas hoida esimest täringut ehk ei lase täringul veereda
        public bool Kas2Hoia = false; //Kas hoida teist täringut
        public bool Kas3Hoia = false; //Kas hoida kolmandat täringut
        public bool Kas4Hoia = false; //Kas hoida neljandat täringut
        public bool Kas5Hoia = false; //Kas hoida viiendat täringut
        public bool KasOn1 = false; //Kas ühed on olemas ehk kas ühtede väärtus on lisatud tabelisse
        public bool KasOn2 = false; //Kas kahed on olemas                   2
        public bool KasOn3 = false; //Kas kolmed on olemas                  3
        public bool KasOn4 = false; //Kas neljad on olemas                  4
        public bool KasOn5 = false; //Kas viied on olemas                   5
        public bool KasOn6 = false; //Kas kuued on olemas                   6
        public bool KasOnKolmik = false; //Kas kolmik on olemas             7
        public bool KasOnNelik = false; //Kas nelik on olemas               8
        public bool KasOnMaja = false; //Kas maja on olemas                 9
        public bool KasOnVäikeRida = false; //Kas väike rida on olemas      10
        public bool KasOnSuurRida = false; //Kas suur rida on olemas        11
        public bool KasOnKorsten = false; //Kas korsten on olemas           12
        public bool KasOnYahtzee = false; //Kas Yahtzee on olemas           13
        public bool KasOnBoonus = false; //Kas boonus on olemas             14
        public int number1 = 0; //Esimese täringu väärtus                   Sõnastike võtmed, sest arrayle ei saa elemente lisada
        public int number2 = 0; //Teise täringu väärtus
        public int number3 = 0; //Kolmanda täringu väärtus
        public int number4 = 0; //Neljanda täringu väärtus
        public int number5 = 0; //Viienda täringu väärtus
        public int Veeretusi = 0; //Mitu veeretust on tehtud
        public int[] arvud = new int[5]; //Täringute array ehk järjend
        public int[] järjestarvud = new int[5]; //Täringute array ehk järjend madalamast suuremani
        public Dictionary<int, int> sõnastik = new Dictionary<int, int>(); //Sõnastik väärtuste jaoks tabelis
        public string a = "Veeretasid: " + 0.ToString(); //Täringute algseis
        public bool Läbi = false; //Kas mäng on läbi
        public bool KasJätka = false; //Kas mängu jätkati
        public string connectionString = //Ühendumissõne
                "Server=tcp:vhk-12r.database.windows.net,1433;" +
                "Initial Catalog=Nimetu;" +
                "User ID=Nimetu;" +
                "Password=oG5fBnyP;" +
                "Encrypt=True;" +
                "TrustServerCertificate=False;" +
                "Connection Timeout=30;";
        
        private void Vajuta_nuppu_Click(object sender, RoutedEventArgs e)
        {

            if (Veeretusi < 3)
            {
                Random rand = new Random();
                //Kui ei paluta täringuid hoida, siis veeretab täringuid ja muudab vastavalt silte täringutel
                if (!Kas1Hoia) { number1 = rand.Next(1, 7); Täring1.Content = "Veeretasid: " + number1.ToString(); }
                if (!Kas2Hoia) { number2 = rand.Next(1, 7); Täring2.Content = "Veeretasid: " + number2.ToString(); }
                if (!Kas3Hoia) { number3 = rand.Next(1, 7); Täring3.Content = "Veeretasid: " + number3.ToString(); }
                if (!Kas4Hoia) { number4 = rand.Next(1, 7); Täring4.Content = "Veeretasid: " + number4.ToString(); }
                if (!Kas5Hoia) { number5 = rand.Next(1, 7); Täring5.Content = "Veeretasid: " + number5.ToString(); }
                //Annab väärtused arvude järjendile ehk arrayle
                arvud[0] = number1; arvud[1] = number2; arvud[2] = number3; arvud[3] = number4; arvud[4] = number5;
                Veeretusi++;
                //Silt näitab mitu korda on veeretatud koos lisaklausliga, et kui on kolm korda, siis lisab, et peab väärtuse tabelisse valima
                Veeretatud.Content = (Veeretusi == 3) ? "Oled veeretanud " + Veeretusi.ToString() + " korda, vali väärtus tabelisse." : "Oled veeretanud " + Veeretusi.ToString() + " korda.";
                järjestarvud = (from element in arvud orderby element ascending select element).ToArray();
                NäitaVäärtust();

            }
            if (Läbi) { UusMäng(); }
        }
        private void Hoia1_Click(object sender, RoutedEventArgs e)
        {
            Kas1Hoia = !Kas1Hoia;
            Hoia1.Content = (Kas1Hoia) ? "Hoian" : "Hoia";
            //Muudab hoia nupu punaseks. et oleks lihtsam aru saada, mida hoiad
            Hoia1.Background = (Kas1Hoia) ? Brushes.Red : SystemColors.ControlBrush;
        }

        private void Hoia2_Click(object sender, RoutedEventArgs e)
        {
            Kas2Hoia = !Kas2Hoia;
            Hoia2.Content = (Kas2Hoia) ? "Hoian" : "Hoia";
            Hoia2.Background = (Kas2Hoia) ? Brushes.Red : SystemColors.ControlBrush;
        }

        private void Hoia3_Click(object sender, RoutedEventArgs e)
        {
            Kas3Hoia = !Kas3Hoia;
            Hoia3.Content = (Kas3Hoia) ? "Hoian" : "Hoia";
            Hoia3.Background = (Kas3Hoia) ? Brushes.Red : SystemColors.ControlBrush;
        }
        private void Hoia4_Click(object sender, RoutedEventArgs e)
        {
            Kas4Hoia = !Kas4Hoia;
            Hoia4.Content = (Kas4Hoia) ? "Hoian" : "Hoia";
            Hoia4.Background = (Kas4Hoia) ? Brushes.Red : SystemColors.ControlBrush;
        }

        private void Hoia5_Click(object sender, RoutedEventArgs e)
        {
            Kas5Hoia = !Kas5Hoia;
            Hoia5.Content = (Kas5Hoia) ? "Hoian" : "Hoia";
            Hoia5.Background = (Kas5Hoia) ? Brushes.Red : SystemColors.ControlBrush;
        }


        private void ÜksNupp_Click(object sender, RoutedEventArgs e)
        {
            //Kui ühtede tulp ei ole täidetud, siis lisab väärtused meetodiga,
            //värskendab veeretused, muudab siltide väärtuseid ja lisab ühtede
            //väärtuse sõnastikku ja nii iga lahtriga
            if (!KasOn1)
            {
                ÜksLabel.Foreground = System.Windows.Media.Brushes.White;
                ÜksLabel.Content = MituNumbrit(1, arvud);
                ÜksNupp.Content = "Ühed olemas";
                KasOn1 = true;
                sõnastik.Add(1, MituNumbrit(1, arvud));
                string väärtus = MituNumbrit(1, arvud).ToString();
                UuendaAndmed(connectionString, "Ones", väärtus);
                Refresh();
            }
        }
        private void KaksNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn2)
            {
                KaksLabel.Foreground = System.Windows.Media.Brushes.White;
                KaksLabel.Content = MituNumbrit(2, arvud);
                KaksNupp.Content = "Kahed olemas";
                KasOn2 = true;
                sõnastik.Add(2, MituNumbrit(2, arvud));
                string väärtus = MituNumbrit(2, arvud).ToString();
                UuendaAndmed(connectionString, "Twos", väärtus);
                Refresh();
            }
        }
        private void KolmNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn3)
            {
                KolmLabel.Foreground = System.Windows.Media.Brushes.White;
                KolmLabel.Content = MituNumbrit(3, arvud);
                KolmNupp.Content = "Kolmed olemas";
                KasOn3 = true;
                sõnastik.Add(3, MituNumbrit(3, arvud));
                string väärtus = MituNumbrit(3, arvud).ToString();
                UuendaAndmed(connectionString, "Threes", väärtus);
                Refresh();
            }
        }
        private void NeliNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn4)
            {
                NeliLabel.Foreground = System.Windows.Media.Brushes.White;
                NeliLabel.Content = MituNumbrit(4, arvud);
                NeliNupp.Content = "Neljad olemas";
                KasOn4 = true;
                sõnastik.Add(4, MituNumbrit(4, arvud));
                string väärtus = MituNumbrit(4, arvud).ToString();
                UuendaAndmed(connectionString, "Fours", väärtus);
                Refresh();
            }
        }

        private void ViisNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn5)
            {
                ViisLabel.Foreground = System.Windows.Media.Brushes.White;
                ViisLabel.Content = MituNumbrit(5, arvud);
                ViisNupp.Content = "Viied olemas";
                KasOn5 = true;
                sõnastik.Add(5, MituNumbrit(5, arvud));
                string väärtus = MituNumbrit(5, arvud).ToString();
                UuendaAndmed(connectionString, "Fives", väärtus);
                Refresh();
            }
        }

        private void KuusNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOn6)
            {
                KuusLabel.Foreground = System.Windows.Media.Brushes.White;
                KuusLabel.Content = MituNumbrit(6, arvud);
                KuusNupp.Content = "Kuued olemas";
                KasOn6 = true;
                sõnastik.Add(6, MituNumbrit(6, arvud));
                string väärtus = MituNumbrit(6, arvud).ToString();
                UuendaAndmed(connectionString, "Sixes", väärtus);
                Refresh();
            }
        }
        private void KolmikNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnKolmik)
            {
                KolmikLabel.Foreground = System.Windows.Media.Brushes.White;
                KolmikLabel.Content = Kolmik(järjestarvud);
                KolmikNupp.Content = "Kolmik olemas";
                KasOnKolmik = true;
                sõnastik.Add(7, Kolmik(järjestarvud));
                string väärtus = Kolmik(järjestarvud).ToString();
                UuendaAndmed(connectionString, "ThreeKind", väärtus);
                Refresh();
            }

        }

        private void NelikNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnNelik)
            {
                NelikLabel.Foreground = System.Windows.Media.Brushes.White;
                NelikLabel.Content = Nelik(järjestarvud);
                NelikNupp.Content = "Nelik olemas";
                KasOnNelik = true;
                sõnastik.Add(8, Nelik(järjestarvud));
                string väärtus = Nelik(järjestarvud).ToString();
                UuendaAndmed(connectionString, "FourKind", väärtus);
                Refresh();
            }
        }

        private void MajaNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnMaja)
            {
                MajaLabel.Foreground = System.Windows.Media.Brushes.White;
                MajaLabel.Content = Maja(järjestarvud);
                MajaNupp.Content = "Maja olemas";
                KasOnMaja = true;
                sõnastik.Add(9, Maja(järjestarvud));
                string väärtus = Maja(järjestarvud).ToString();
                UuendaAndmed(connectionString, "FullHouse", väärtus);
                Refresh();
            }
        }
        private void VäikeNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnVäikeRida)
            {
                VäikeLabel.Foreground = System.Windows.Media.Brushes.White;
                VäikeLabel.Content = Väike(järjestarvud);
                VäikeNupp.Content = "Väike rida olemas";
                KasOnVäikeRida = true;
                sõnastik.Add(10, Väike(järjestarvud));
                string väärtus = Väike(järjestarvud).ToString();
                UuendaAndmed(connectionString, "SmallStraight", väärtus);
                Refresh();
            }
        }

        private void SuurNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnSuurRida)
            {
                SuurLabel.Foreground = System.Windows.Media.Brushes.White;
                SuurLabel.Content = Suur(järjestarvud);
                SuurNupp.Content = "Suur rida olemas";
                KasOnSuurRida = true;
                sõnastik.Add(11, Suur(järjestarvud));
                string väärtus = Suur(järjestarvud).ToString();
                UuendaAndmed(connectionString, "LargeStraight", väärtus);
                Refresh();
            }
        }

        private void KorstenNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnKorsten)
            {
                KorstenLabel.Foreground = System.Windows.Media.Brushes.White;
                KorstenLabel.Content = Summa(järjestarvud);
                KorstenNupp.Content = "Korsten olemas";
                KasOnKorsten = true;
                sõnastik.Add(12, Summa(järjestarvud));
                string väärtus = Summa(järjestarvud).ToString();
                UuendaAndmed(connectionString, "Chance", väärtus);
                Refresh();
            }
        }
        private void YahtzeeNupp_Click(object sender, RoutedEventArgs e)
        {
            if (!KasOnYahtzee)
            {
                YahtzeeLabel.Foreground = System.Windows.Media.Brushes.White;
                YahtzeeNupp.Content = "Yahtzee olemas";
                KasOnYahtzee = true;
                sõnastik.Add(13, Yahtzee(järjestarvud));
                string väärtus = Yahtzee(järjestarvud).ToString();
                UuendaAndmed(connectionString, "Yahtzee", väärtus);
                YahtzeeLabel.Content = väärtus;
                Refresh();
            }

        }
        
        public static int MituNumbrit(int otsitav, int[] arr)
        {
            //Leiab mitu korda number esineb ning tagastab esinemisarvu korrutise
            //antud numbriga, et saada väärtuse
            int esineb = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == otsitav)
                {
                    esineb++;
                }
            }
            return esineb * otsitav;
        }
        public void Refresh()
        {
            //Värskendab veeretused nulli ja muudab täringud nulliks ning hoia vääraks
            Veeretusi = 0;
            Veeretatud.Content = "Oled veeretanud " + Veeretusi.ToString() + " korda.";
            number1 = 0; number2 = 0; number3 = 0; number4 = 0; number5 = 0;
            Täring1.Content = a; Täring2.Content = a; Täring3.Content = a; Täring4.Content = a; Täring5.Content = a;
            Kas1Hoia = false; Kas2Hoia = false; Kas3Hoia = false; Kas4Hoia = false; Kas5Hoia = false;
            Hoia1.Content = "Hoia"; Hoia2.Content = "Hoia"; Hoia3.Content = "Hoia"; Hoia4.Content = "Hoia"; Hoia5.Content = "Hoia";
            arvud[0] = 0; arvud[1] = 0; arvud[2] = 0; arvud[3] = 0; arvud[4] = 0;
            järjestarvud[0] = 0; järjestarvud[1] = 0; järjestarvud[2] = 0; järjestarvud[3] = 0; järjestarvud[4] = 0;
            if (!KasOn1) { ÜksLabel.Content = ""; }
            if (!KasOn2) { KaksLabel.Content = ""; }
            if (!KasOn3) { KolmLabel.Content = ""; }
            if (!KasOn4) { NeliLabel.Content = ""; }
            if (!KasOn5) { ViisLabel.Content = ""; }
            if (!KasOn6) { KuusLabel.Content = ""; }
            if (!KasOnKolmik) { KolmikLabel.Content = ""; }
            if (!KasOnNelik) { NelikLabel.Content = ""; }
            if (!KasOnMaja) { MajaLabel.Content = ""; }
            if (!KasOnVäikeRida) { VäikeLabel.Content = ""; }
            if (!KasOnSuurRida) { SuurLabel.Content = ""; }
            if (!KasOnKorsten) { KorstenLabel.Content = ""; }
            if (!KasOnYahtzee) { YahtzeeLabel.Content = ""; }
            Hoia1.Background = SystemColors.ControlBrush;
            Hoia2.Background = SystemColors.ControlBrush;
            Hoia3.Background = SystemColors.ControlBrush;
            Hoia4.Background = SystemColors.ControlBrush;
            Hoia5.Background = SystemColors.ControlBrush;
            KasBoonus();
            KasMängOnLäbi();
        }
        public static int Kolmik(int[] arr)
        {
            //Kontrollib kolmiku olemasolu ja tagastab väärtuse
            //edasised kontrollivad teisi lahtreid
            int Väärtus = 0;
            if ((arr[0] == arr[2]) || (arr[1] == arr[3]) || (arr[2] == arr[4]))
            {
                Väärtus = Summa(arr);
            }
            return Väärtus;
        }
        public static int Nelik(int[] arr)
        {
            int Väärtus = 0;
            if ((arr[0] == arr[3]) || (arr[1] == arr[4]))
            {
                Väärtus = Summa(arr);
            }
            return Väärtus;
        }
        public static int Maja(int[] arr)
        {
            int Väärtus = 0;
            if ((arr[0] == arr[2] & arr[3] == arr[4] & arr[0] != arr[4]) || (arr[0] == arr[1] & arr[2] == arr[4] & arr[0] != arr[4]))
            {
                Väärtus = 25;
            }
            return Väärtus;
        }
        public static int Väike(int[] arr)
        {
            int Väärtus = 0; //väär viis nt [2, 3, 3, 4, 5] ei ole
            if (((arr[0] == 1 || arr[1] == 1) & (arr[1] == 2 || arr[2] == 2) & (arr[2] == 3 || arr[3] == 3) & (arr[3] == 4 || arr[4] == 4)) || ((arr[0] == 2 || arr[1] == 2) & (arr[1] == 3 || arr[2] == 3) & (arr[2] == 4 || arr[3] == 4) & (arr[3] == 5 || arr[4] == 5)) || ((arr[0] == 3 || arr[1] == 3) & (arr[1] == 4 || arr[2] == 4) & (arr[2] == 5 || arr[3] == 5) & (arr[3] == 6 || arr[4] == 6)))
            {
                Väärtus = 30;
            }
            return Väärtus;
        }
        public static int Suur(int[] arr)
        {
            int Väärtus = 0;
            if (arr[0] + 1 == arr[1] & arr[0] + 2 == arr[2] & arr[0] + 3 == arr[3] & arr[0] + 4 == arr[4])
            {
                Väärtus = 40;
            }
            return Väärtus;
        }
        public static int Yahtzee(int[] arr)
        {
            int Väärtus = 0;
            if (arr[0] == arr[4] & arr[0] != 0)
            {
                Väärtus = 50;
            }
            return Väärtus;
        }
        public static int Summa(int[] arr)
        {
            return arr[0] + arr[1] + arr[2] + arr[3] + arr[4];
        }
        public void KasMängOnLäbi()
        {
            //Kontrollib, kas mäng on läbi, kui on, siis lisab lõpetamissildi
            if (KasOn1 & KasOn2 & KasOn3 & KasOn4 & KasOn5 & KasOn6 & KasOnKolmik & KasOnNelik & KasOnMaja & KasOnSuurRida & KasOnVäikeRida & KasOnKorsten & KasOnYahtzee)
            {
                int puhver = 0;
                foreach (var ele in sõnastik)
                {
                    puhver += ele.Value;
                }
                if (puhver >= Convert.ToInt32(SaaParim(connectionString)))
                {
                    string summa = puhver.ToString();
                    UuendaParim(connectionString, summa);
                    MängLõpp.Content = "Mäng lõppes, \nsinu summaks on:\n" + puhver.ToString() + " punkti!\nSee on uus rekord!";
                }
                else
                {
                    MängLõpp.Content = "Mäng lõppes, \nsinu summaks on:\n" + puhver.ToString() + " punkti!\nPraegune rekord on\n" + SaaParim(connectionString) + " punkti.";
                }
                Vajuta_nuppu.Content = "Alusta uut mängu";
                Läbi = true;
                AlgTabel(connectionString);

            }
        }
        public void UusMäng()
        {
            //Alustab uut mängu, värskendab kõik algseisu
            KasOn1 = false; KasOn2 = false; KasOn3 = false; KasOn4 = false; KasOn5 = false; KasOn6 = false;
            KasOnKolmik = false; KasOnNelik = false; KasOnMaja = false; KasOnSuurRida = false; KasOnVäikeRida = false; KasOnKorsten = false; KasOnYahtzee = false; KasOnBoonus = false;
            ÜksLabel.Content = ""; KaksLabel.Content = ""; KolmLabel.Content = ""; NeliLabel.Content = ""; ViisLabel.Content = ""; KuusLabel.Content = "";
            KolmikLabel.Content = ""; NelikLabel.Content = ""; MajaLabel.Content = ""; SuurLabel.Content = ""; VäikeLabel.Content = ""; KorstenLabel.Content = ""; YahtzeeLabel.Content = "";
            ÜksNupp.Content = "Ühed"; KaksNupp.Content = "Kahed"; KolmNupp.Content = "Kolmed"; NeliNupp.Content = "Neljad"; ViisNupp.Content = "Viied"; KuusNupp.Content = "Kuued";
            KolmikNupp.Content = "Kolmik"; NelikNupp.Content = "Nelik"; MajaNupp.Content = "Maja"; VäikeNupp.Content = "Väike rida"; SuurNupp.Content = "Suur rida"; KorstenNupp.Content = "Korsten"; YahtzeeNupp.Content = "Yahtzee";
            Vajuta_nuppu.Content = "Veereta täringuid";
            MängLõpp.Content = "";
            KokkuLabel.Content = ""; BoonusLabel.Content = "";
            Veeretusi = 0;
            Refresh();
            sõnastik.Clear();
            Läbi = false;
            Värv(System.Windows.Media.Brushes.Black);

        }
        public void NäitaVäärtust()
        {
            if (!KasOn1) { ÜksLabel.Content = MituNumbrit(1, arvud); }
            if (!KasOn2) { KaksLabel.Content = MituNumbrit(2, arvud); }
            if (!KasOn3) { KolmLabel.Content = MituNumbrit(3, arvud); }
            if (!KasOn4) { NeliLabel.Content = MituNumbrit(4, arvud); }
            if (!KasOn6) { KuusLabel.Content = MituNumbrit(6, arvud); }
            if (!KasOn5) { ViisLabel.Content = MituNumbrit(5, arvud); }
            if (!KasOnKolmik) { KolmikLabel.Content = Kolmik(järjestarvud); }
            if (!KasOnNelik) { NelikLabel.Content = Nelik(järjestarvud); }
            if (!KasOnMaja) { MajaLabel.Content = Maja(järjestarvud); }
            if (!KasOnSuurRida) { SuurLabel.Content = Suur(järjestarvud); }
            if (!KasOnVäikeRida) { VäikeLabel.Content = Väike(järjestarvud); }
            if (!KasOnKorsten) { KorstenLabel.Content = Summa(arvud); }
            if (!KasOnYahtzee) { YahtzeeLabel.Content = Yahtzee(järjestarvud); }
        }
        public void KasBoonus()
        {
            if (KasOn1 & KasOn2 & KasOn3 & KasOn4 & KasOn5 & KasOn6 & !KasOnBoonus)
            {
                KasOnBoonus = true;
                KokkuLabel.Content = SummaDict(sõnastik);
                if (SummaDict(sõnastik) >= 63)
                {
                    BoonusLabel.Content = 35;
                    sõnastik.Add(14, 35);
                }
                else { BoonusLabel.Content = 0; }
            }
        }
        public static int SummaDict(Dictionary<int, int> väärtused)
        {
            int tagastus = 0;
            for (int i = 1; i < 7; i++)
            {
                tagastus += väärtused[i];
            }
            return tagastus;
        }
        private static string SaaParim(string connectionString)
        {
            string queryString = "SELECT * FROM dbo.Highscore;";
            string loetu = "";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command1 = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command1.ExecuteReader();

                while (reader.Read())
                {
                    //Console.WriteLine($"{reader[0]}");
                    loetu = ($"{reader[0]}");
                }
                reader.Close();
                connection.Close();
            }
            return loetu;
        }
        private void UuendaParim(string connectionString, string väärtus)
        {

            string queryString = "Update Highscore set High = " + väärtus;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command2 = new SqlCommand(queryString, connection);
                connection.Open();
                command2.ExecuteNonQuery();
                connection.Close();
            }
        }
        private void UuendaAndmed(string connectionString, string kuhu, string väärtus)
        {

            string queryString = "Update Score set " + kuhu + " = " + väärtus;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command2 = new SqlCommand(queryString, connection);
                connection.Open();
                command2.ExecuteNonQuery();
                connection.Close();
            }
        }
        private static string SaaAndmed(string connectionString, string mida)
        {

            string queryString = "SELECT " + mida + " from Score";
            string loetu = "";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command1 = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command1.ExecuteReader();

                while (reader.Read())
                {
                    //Console.WriteLine($"{reader[0]}");
                    loetu = ($"{reader[0]}");
                }
                reader.Close();
                connection.Close();
            }
            return loetu;
        }
        private void AlgTabel(string connectionString)
        {
            string queryString = "Update Score set Ones=NULL, Twos=NULL, Threes=NULL, Fours=NULL, Fives=NULL, Sixes =NULL, ThreeKind=NULL, FourKind=NULL, FullHouse=NULL, SmallStraight=NULL, LargeStraight=NULL, Chance=NULL, Yahtzee=NULL";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command2 = new SqlCommand(queryString, connection);
                connection.Open();
                command2.ExecuteNonQuery();
                connection.Close();
            }
        }
        private void Tekstivärv(SolidColorBrush värv)
        {
            ÜksLabel.Foreground = värv; KaksLabel.Foreground = värv;
            KolmLabel.Foreground = värv; NeliLabel.Foreground = värv;
            ViisLabel.Foreground = värv; KuusLabel.Foreground = värv;
            KolmikLabel.Foreground = värv; NelikLabel.Foreground = värv;
            MajaLabel.Foreground = värv; VäikeLabel.Foreground = värv;
            SuurLabel.Foreground = värv; KorstenLabel.Foreground = värv;
            YahtzeeLabel.Foreground = värv;
        }
        private void Värv(SolidColorBrush v)
        {
            if (!KasOn1) { ÜksLabel.Foreground = v; ÜksLabel.Content = ""; }
            if (!KasOn2) { KaksLabel.Foreground = v; KaksLabel.Content = ""; }
            if (!KasOn3) { KolmLabel.Foreground = v; KolmLabel.Content = ""; }
            if (!KasOn4) { NeliLabel.Foreground = v; NeliLabel.Content = ""; }
            if (!KasOn6) { KuusLabel.Foreground = v; KuusLabel.Content = ""; }
            if (!KasOn5) { ViisLabel.Foreground = v; ViisLabel.Content = ""; }
            if (!KasOnKolmik) { KolmikLabel.Foreground = v; KolmikLabel.Content = ""; }
            if (!KasOnNelik) { NelikLabel.Foreground = v; NelikLabel.Content = ""; }
            if (!KasOnMaja) { MajaLabel.Foreground = v; MajaLabel.Content = ""; }
            if (!KasOnSuurRida) { SuurLabel.Foreground = v; SuurLabel.Content = ""; }
            if (!KasOnVäikeRida) { VäikeLabel.Foreground = v; VäikeLabel.Content = ""; }
            if (!KasOnKorsten) { KorstenLabel.Foreground = v; KorstenLabel.Content = ""; }
            if (!KasOnYahtzee) { YahtzeeLabel.Foreground = v; YahtzeeLabel.Content = ""; }
        }
        private void EiJätka1()
        {
            string queryString = "Update Jätka set Kas1=0"; //Kõver viis teha, aga saab sellega tehtud
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command2 = new SqlCommand(queryString, connection);
                connection.Open();
                command2.ExecuteNonQuery();
                connection.Close();
            }
        }
        private void LisaSõnastikku(Dictionary<int, int> väärtused)
        {
            if (KasOn1) { väärtused.Add(1, Convert.ToInt32(ÜksLabel.Content)); }
            if (KasOn2) { väärtused.Add(2, Convert.ToInt32(KaksLabel.Content)); }
            if (KasOn3) { väärtused.Add(3, Convert.ToInt32(KolmLabel.Content)); }
            if (KasOn4) { väärtused.Add(4, Convert.ToInt32(NeliLabel.Content)); }
            if (KasOn5) { väärtused.Add(5, Convert.ToInt32(ViisLabel.Content)); }
            if (KasOn6) { väärtused.Add(6, Convert.ToInt32(KuusLabel.Content)); }
            if (KasOnKolmik) { väärtused.Add(7, Convert.ToInt32(KolmikLabel.Content)); }
            if (KasOnNelik) { väärtused.Add(8, Convert.ToInt32(NelikLabel.Content)); }
            if (KasOnMaja) { väärtused.Add(9, Convert.ToInt32(MajaLabel.Content)); }
            if (KasOnVäikeRida) { väärtused.Add(10, Convert.ToInt32(VäikeLabel.Content)); }
            if (KasOnSuurRida) { väärtused.Add(11, Convert.ToInt32(SuurLabel.Content)); }
            if (KasOnKorsten) { väärtused.Add(12, Convert.ToInt32(KorstenLabel.Content)); }
            if (KasOnYahtzee) { väärtused.Add(13, Convert.ToInt32(YahtzeeLabel.Content)); }
        }
        private void Jätka_Click()
        {
            Tekstivärv(System.Windows.Media.Brushes.White);
            string üks = SaaAndmed(connectionString, "Ones"); string kaks = SaaAndmed(connectionString, "Twos");
            string kolm = SaaAndmed(connectionString, "Threes"); string neli = SaaAndmed(connectionString, "Fours");
            string viis = SaaAndmed(connectionString, "Fives"); string kuus = SaaAndmed(connectionString, "Sixes");
            string kolmik = SaaAndmed(connectionString, "ThreeKind"); string nelik = SaaAndmed(connectionString, "FourKind");
            string maja = SaaAndmed(connectionString, "FullHouse"); string väike = SaaAndmed(connectionString, "SmallStraight");
            string suur = SaaAndmed(connectionString, "LargeStraight"); string korsten = SaaAndmed(connectionString, "Chance");
            string Yah = SaaAndmed(connectionString, "Yahtzee");
            ÜksLabel.Content = üks; KaksLabel.Content = kaks;
            KolmLabel.Content = kolm; NeliLabel.Content = neli;
            ViisLabel.Content = viis; KuusLabel.Content = kuus;
            KolmikLabel.Content = kolmik; NelikLabel.Content = nelik;
            MajaLabel.Content = maja; VäikeLabel.Content = väike;
            SuurLabel.Content = suur; KorstenLabel.Content = korsten;
            YahtzeeLabel.Content = Yah;
            KasOn1 = (üks != ""); KasOn2 = (kaks != "");
            KasOn3 = (kolm != ""); KasOn4 = (neli != "");
            KasOn5 = (viis != ""); KasOn6 = (kuus != "");
            KasOnKolmik = (kolmik != ""); KasOnNelik = (nelik != "");
            KasOnMaja = (maja != ""); KasOnVäikeRida = (väike != "");
            KasOnSuurRida = (suur != ""); KasOnKorsten = (korsten != "");
            KasOnYahtzee = (Yah != "");
            Värv(System.Windows.Media.Brushes.Black);
            LisaSõnastikku(sõnastik);
        }
        private static bool KasJätkab1(string connectionString)
        {
            string queryString = "SELECT Kas1 from Jätka";
            string loetu = "";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command1 = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command1.ExecuteReader();

                while (reader.Read())
                {
                    //Console.WriteLine($"{reader[0]}");
                    loetu = ($"{reader[0]}"); //On sõne
                }
                reader.Close();
                connection.Close();
            }
            return Convert.ToBoolean(Convert.ToInt32(loetu)); //Muudab sõne numbriks ja siis tõeväärtuseks
        }
        private static bool KasJätkab2(string connectionString)
        {
            string queryString = "SELECT Kas2 from Jätka";
            string loetu = "";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command1 = new SqlCommand(queryString, connection);
                connection.Open();
                SqlDataReader reader = command1.ExecuteReader();

                while (reader.Read())
                {
                    //Console.WriteLine($"{reader[0]}");
                    loetu = ($"{reader[0]}"); //On sõne
                }
                reader.Close();
                connection.Close();
            }
            return Convert.ToBoolean(Convert.ToInt32(loetu)); //Muudab sõne numbriks ja siis tõeväärtuseks
        }
        private void EiJätka2()
        {
            string queryString = "Update Jätka set Kas2=0"; //Kõver viis teha, aga saab sellega tehtud
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command2 = new SqlCommand(queryString, connection);
                connection.Open();
                command2.ExecuteNonQuery();
                connection.Close();
            }
        }


    }
}
